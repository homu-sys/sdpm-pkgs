#!/bin/bash
set -e
[ "$(id -u)" -ne 0 ] && { echo "[error] must be root" >&2; exit 1; }

echo "[info] installing dependencies..."
pacman -S --needed --noconfirm \
    gcc make autoconf automake pkg-config \
    libcap curl wget \
    > /dev/null 2>&1 || true

BUILD="/tmp/sdpm-zsh-build"
mkdir -p "$BUILD" && cd "$BUILD"

if [ ! -d "zsh" ]; then
    git clone --depth 1 https://github.com/zsh-users/zsh.git
fi

cd zsh
./configure --prefix=/usr/local --with-tcsetpgrp
make -j"$(nproc)"
make install

cd / && rm -rf "$BUILD"
echo "[info] zsh installed"
