#!/bin/bash
set -e
[ "$(id -u)" -ne 0 ] && { echo "[error] must be root" >&2; exit 1; }

echo "[info] installing dependencies..."
pacman -S --needed --noconfirm \
    cmake ninja gcc pkg-config unzip curl \
    gettext libuv libvterm luajit msgpack libtree-sitter \
    > /dev/null 2>&1 || true

BUILD="/tmp/sdpm-neovim-build"
mkdir -p "$BUILD" && cd "$BUILD"

if [ ! -d "neovim" ]; then
    git clone --depth 1 --branch stable https://github.com/neovim/neovim.git
fi

cd neovim
cmake -B build -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX=/usr/local
cmake --build build -j"$(nproc)"
cmake --install build

cd / && rm -rf "$BUILD"
echo "[info] neovim installed"
