#!/bin/bash
set -e
[ "$(id -u)" -ne 0 ] && { echo "[error] must be root" >&2; exit 1; }

echo "[info] installing dependencies..."
pacman -S --needed --noconfirm \
    meson ninja gcc pkg-config \
    cmake libpcre2 libinitial-state \
    > /dev/null 2>&1 || true

BUILD="/tmp/sdpm-fish-build"
mkdir -p "$BUILD" && cd "$BUILD"

if [ ! -d "fish" ]; then
    git clone --depth 1 https://github.com/fish-shell/fish-shell.git
fi

cd fish
cmake -B build -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX=/usr/local
cmake --build build -j"$(nproc)"
cmake --install build

cd / && rm -rf "$BUILD"
echo "[info] fish installed"
