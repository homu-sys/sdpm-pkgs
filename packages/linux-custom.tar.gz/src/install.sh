#!/bin/bash
# sdpm kernel installer - builds from source and installs to /boot
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
CONFIG="$SCRIPT_DIR/config"
KERNEL_VERSION="${1:-6.15.6}"
KNAME="custom"
BUILD_DIR="/tmp/sdpm-kernel-build"
EFIDIR="/boot/EFI/Linux"
CMDLINE_FILE="$SCRIPT_DIR/cmdline"

if [ "$(id -u)" -ne 0 ]; then
    echo "[error] must be run as root" >&2
    exit 1
fi

echo "[info] building kernel ${KERNEL_VERSION} (${KNAME})..."

mkdir -p "$BUILD_DIR" "$EFIDIR"

cd "$BUILD_DIR"

# download
TARBALL="linux-${KERNEL_VERSION}.tar.xz"
if [ ! -f "$TARBALL" ]; then
    echo "[info] downloading linux ${KERNEL_VERSION}..."
    curl -fSL "https://cdn.kernel.org/pub/linux/kernel/v${KERNEL_VERSION%%.*}.x/${TARBALL}" -o "$TARBALL"
fi

if [ ! -d "linux-${KERNEL_VERSION}" ]; then
    echo "[info] extracting..."
    tar xf "$TARBALL"
fi

cd "linux-${KERNEL_VERSION}"

# apply config
cp "$CONFIG" .config
make olddefconfig

# build
JOBS=$(nproc)
echo "[info] compiling with ${JOBS} jobs..."
make -j"$JOBS" bzImage modules

# install modules
echo "[info] installing modules..."
make modules_install INSTALL_MOD_PATH=/

# create efi stub image
VMLINUX="arch/x86/boot/bzImage"
STUB="$EFIDIR/${KNAME}_linux.efi"

echo "[info] creating efi stub: $STUB"
objcopy \
    --add-section .osrel="/etc/os-release" --change-section-vma .osrel=0x20000 \
    --add-section .cmdline="$CMDLINE_FILE" --change-section-vma .cmdline=0x30000 \
    --add-section .linux="$VMLINUX" --change-section-vma .linux=0x40000 \
    /usr/lib/systemd/boot/efi/linuxx64.efi.stub "$STUB"

# cleanup build dir
cd /
rm -rf "$BUILD_DIR"

echo "[info] kernel ${KERNEL_VERSION} installed to $STUB"
echo "[info] update your bootloader config if needed"
