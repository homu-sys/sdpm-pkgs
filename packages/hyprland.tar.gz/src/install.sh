#!/bin/bash
set -e
[ "$(id -u)" -ne 0 ] && { echo "[error] must be root" >&2; exit 1; }

echo "[info] installing dependencies..."
pacman -S --needed --noconfirm \
    meson ninja gcc cmake glaze glm libinput libxkbcommon \
    wayland wayland-protocols libdisplay-info libliftoff \
    libinput libgbm pango cairo libxml2 libdrm \
    xorg-xwayland hwdata libseat libxcb xcb-util \
    xcb-util-keysyms xcb-util-renderutil xcb-util-wm \
    hyprland-protocols hyprlang hyprutils hyprcursor \
    aquamarine opengl-vendor \
    > /dev/null 2>&1 || true

BUILD="/tmp/sdpm-hyprland-build"
mkdir -p "$BUILD" && cd "$BUILD"

if [ ! -d "Hyprland" ]; then
    git clone --depth 1 https://github.com/hyprwm/Hyprland.git
fi

cd Hyprland
cmake -B build -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX=/usr/local
cmake --build build -j"$(nproc)"
cmake --install build

cd / && rm -rf "$BUILD"
echo "[info] hyprland installed"
