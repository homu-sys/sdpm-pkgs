#!/bin/bash
set -e
[ "$(id -u)" -ne 0 ] && { echo "[error] must be root" >&2; exit 1; }

echo "[info] installing dependencies..."
pacman -S --needed --noconfirm \
    meson ninja gcc pkg-config \
    gtk3 libxkbcommon wayland-protocols \
    libnl pango cairo librsvg \
    check-devel libev-devel \
    > /dev/null 2>&1 || true

BUILD="/tmp/sdpm-rofi-build"
mkdir -p "$BUILD" && cd "$BUILD"

if [ ! -d "rofi" ]; then
    git clone --depth 1 https://github.com/DaveDavenport/rofi.git
fi

cd rofi
git submodule update --init
meson setup build --prefix=/usr/local
ninja -C build
ninja -C build install

cd / && rm -rf "$BUILD"
echo "[info] rofi installed"
