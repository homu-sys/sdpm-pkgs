#!/bin/bash
set -e
[ "$(id -u)" -ne 0 ] && { echo "[error] must be root" >&2; exit 1; }

echo "[info] installing dependencies..."
pacman -S --needed --noconfirm \
    meson ninja gcc cmake glaze wayland wayland-protocols \
    libinput libxkbcommon libdrm libgbm pango cairo \
    libwlroots wayland-protocols wlroots \
    json-c pcre2 grep swaybg \
    > /dev/null 2>&1 || true

BUILD="/tmp/sdpm-sway-build"
mkdir -p "$BUILD" && cd "$BUILD"

if [ ! -d "sway" ]; then
    git clone --depth 1 https://github.com/swaywm/sway.git
fi

cd sway
meson setup build --prefix=/usr/local
ninja -C build
ninja -C build install

cd / && rm -rf "$BUILD"
echo "[info] sway installed"
