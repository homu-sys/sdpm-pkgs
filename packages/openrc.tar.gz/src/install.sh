#!/bin/bash
set -e
[ "$(id -u)" -ne 0 ] && { echo "[error] must be root" >&2; exit 1; }

VERSION="${1:-0.55}"
BUILD="/tmp/sdpm-openrc-build"

echo "[info] building openrc ${VERSION}..."
mkdir -p "$BUILD" && cd "$BUILD"

[ ! -f "openrc-${VERSION}.tar.gz" ] && \
    curl -fSL "https://github.com/OpenRC/openrc/archive/refs/tags/${VERSION}.tar.gz" -o "openrc-${VERSION}.tar.gz"
[ ! -d "openrc-${VERSION}" ] && tar xf "openrc-${VERSION}.tar.gz"
cd "openrc-${VERSION}"

make -j"$(nproc)" DESTDIR=/usr/local install

cd / && rm -rf "$BUILD"
echo "[info] openrc ${VERSION} installed"
