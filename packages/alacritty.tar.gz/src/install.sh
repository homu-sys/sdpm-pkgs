#!/bin/bash
set -e
[ "$(id -u)" -ne 0 ] && { echo "[error] must be root" >&2; exit 1; }

echo "[info] installing dependencies..."
pacman -S --needed --noconfirm \
    freetype2 fontconfig libxcb python \
    > /dev/null 2>&1 || true

BUILD="/tmp/sdpm-alacritty-build"
mkdir -p "$BUILD" && cd "$BUILD"

if [ ! -d "alacritty" ]; then
    git clone --depth 1 https://github.com/alacritty/alacritty.git
fi

cd alacritty
cargo build --release --prefix=/usr/local
cargo install --root /usr/local --path .

cd / && rm -rf "$BUILD"
echo "[info] alacritty installed"
