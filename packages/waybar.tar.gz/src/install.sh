#!/bin/bash
set -e
[ "$(id -u)" -ne 0 ] && { echo "[error] must be root" >&2; exit 1; }

echo "[info] installing dependencies..."
pacman -S --needed --noconfirm \
    meson ninja gcc pkg-config \
    wayland-protocols gtkmm3 \
    jsoncpp libsigc++ fmt \
    wayland libgtk-3-dev glib2 \
    > /dev/null 2>&1 || true

BUILD="/tmp/sdpm-waybar-build"
mkdir -p "$BUILD" && cd "$BUILD"

if [ ! -d "waybar" ]; then
    git clone --depth 1 https://github.com/Alexays/Waybar.git
fi

cd waybar
meson setup build --prefix=/usr/local \
    -Dtests=disabled \
    -Dman-pages=disabled
ninja -C build
ninja -C build install

cd / && rm -rf "$BUILD"
echo "[info] waybar installed"
