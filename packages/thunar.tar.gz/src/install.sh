#!/bin/bash
set -e
[ "$(id -u)" -ne 0 ] && { echo "[error] must be root" >&2; exit 1; }

echo "[info] installing dependencies..."
pacman -S --needed --noconfirm \
    meson ninja gcc pkg-config \
    gtk3 xfce4-panel libexif libpng \
    hicolor-icon-theme libnotify \
    > /dev/null 2>&1 || true

BUILD="/tmp/sdpm-thunar-build"
mkdir -p "$BUILD" && cd "$BUILD"

if [ ! -d "thunar" ]; then
    git clone --depth 1 https://gitlab.xfce.org/xfce/thunar.git
fi

cd thunar
meson setup build --prefix=/usr/local
ninja -C build
ninja -C build install

cd / && rm -rf "$BUILD"
echo "[info] thunar installed"
