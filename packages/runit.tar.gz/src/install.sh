#!/bin/bash
set -e
[ "$(id -u)" -ne 0 ] && { echo "[error] must be root" >&2; exit 1; }

BUILD="/tmp/sdpm-runit-build"

echo "[info] building runit..."
mkdir -p "$BUILD" && cd "$BUILD"

[ ! -f "runit-2.1.2.tar.gz" ] && \
    curl -fSL "http://smarden.org/runit/runit-2.1.2.tar.gz" -o runit-2.1.2.tar.gz
[ ! -d "runit-2.1.2" ] && tar xf runit-2.1.2.tar.gz
cd admin/runit-2.1.2

echo "2" | ./package/runit-install

cd / && rm -rf "$BUILD"
echo "[info] runit installed"
