#!/bin/bash
set -e
[ "$(id -u)" -ne 0 ] && { echo "[error] must be root" >&2; exit 1; }

echo "[info] installing dependencies..."
pacman -S --needed --noconfirm \
    meson ninja gcc pkg-config xorgproto libX11 \
    > /dev/null 2>&1 || true

BUILD="/tmp/sdpm-xprop-build"
mkdir -p "$BUILD" && cd "$BUILD"

if [ ! -d "xprop" ]; then
    git clone --depth 1 https://gitlab.freedesktop.org/xorg/app/xprop.git
fi

cd xprop
meson setup build --prefix=/usr/local
ninja -C build
ninja -C build install

cd / && rm -rf "$BUILD"
echo "[info] xorg-xprop installed"
