#!/bin/bash
set -e
[ "$(id -u)" -ne 0 ] && { echo "[error] must be root" >&2; exit 1; }

echo "[info] installing dependencies..."
pacman -S --needed --noconfirm \
    meson ninja gcc pkg-config xorgproto libX11 \
    > /dev/null 2>&1 || true

BUILD="/tmp/sdpm-xinit-build"
mkdir -p "$BUILD" && cd "$BUILD"

if [ ! -d "xinit" ]; then
    git clone --depth 1 https://gitlab.freedesktop.org/xorg/app/xinit.git
fi

cd xinit
meson setup build --prefix=/usr/local
ninja -C build
ninja -C build install

cd / && rm -rf "$BUILD"
echo "[info] xorg-xinit installed"
