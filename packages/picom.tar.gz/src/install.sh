#!/bin/bash
set -e
[ "$(id -u)" -ne 0 ] && { echo "[error] must be root" >&2; exit 1; }

echo "[info] installing dependencies..."
pacman -S --needed --noconfirm \
    meson ninja gcc pkg-config \
    libx11 libxcb xcb-util \
    libxext libgl libev libconfig \
    pcre2 pixman libxml2 \
    > /dev/null 2>&1 || true

BUILD="/tmp/sdpm-picom-build"
mkdir -p "$BUILD" && cd "$BUILD"

if [ ! -d "picom" ]; then
    git clone --depth 1 https://github.com/yshui/picom.git
fi

cd picom
meson setup build --prefix=/usr/local \
    -Dtests=disabled
ninja -C build
ninja -C build install

cd / && rm -rf "$BUILD"
echo "[info] picom installed"
