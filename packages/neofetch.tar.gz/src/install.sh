#!/bin/bash
set -e
[ "$(id -u)" -ne 0 ] && { echo "[error] must be root" >&2; exit 1; }

BUILD="/tmp/sdpm-neofetch-build"
mkdir -p "$BUILD" && cd "$BUILD"

if [ ! -d "neofetch" ]; then
    git clone --depth 1 https://github.com/dylanaraps/neofetch.git
fi

cd neofetch
chmod +x neofetch
cp neofetch /usr/local/bin/

cd / && rm -rf "$BUILD"
echo "[info] neofetch installed"
