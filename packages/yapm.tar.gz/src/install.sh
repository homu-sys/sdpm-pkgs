#!/bin/bash
set -e
[ "$(id -u)" -ne 0 ] && { echo "[error] must be root" >&2; exit 1; }

echo "[info] downloading yapm..."
curl -fsSL "https://raw.githubusercontent.com/commodorial64/yapm/main/yapm.py" -o /usr/local/bin/yapm
chmod +x /usr/local/bin/yapm
mkdir -p /etc/yapm /var/lib/yapm/packages /var/lib/yapm/cache

echo "[info] yapm installed"
