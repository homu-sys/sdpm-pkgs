#!/bin/bash
set -e
[ "$(id -u)" -ne 0 ] && { echo "[error] must be root" >&2; exit 1; }

BUILD="/tmp/sdpm-btop-build"
mkdir -p "$BUILD" && cd "$BUILD"

if [ ! -d "btop" ]; then
    git clone --depth 1 https://github.com/aristocratos/btop.git
fi

cd btop
cmake -B build -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX=/usr/local
cmake --build build -j"$(nproc)"
cmake --install build

cd / && rm -rf "$BUILD"
echo "[info] btop installed"
