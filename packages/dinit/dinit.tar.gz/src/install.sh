#!/bin/bash
# sdpm dinit installer - builds from source
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
BUILD_DIR="/tmp/sdpm-dinit-build"
VERSION="${1:-0.18.0}"

if [ "$(id -u)" -ne 0 ]; then
    echo "[error] must be run as root" >&2
    exit 1
fi

echo "[info] building dinit ${VERSION}..."

mkdir -p "$BUILD_DIR"
cd "$BUILD_DIR"

# download
TARBALL="dinit-${VERSION}.tar.gz"
if [ ! -f "$TARBALL" ]; then
    echo "[info] downloading dinit ${VERSION}..."
    curl -fSL "https://github.com/davmac314/dinit/archive/refs/tags/v${VERSION}.tar.gz" -o "$TARBALL"
fi

if [ ! -d "dinit-${VERSION}" ]; then
    echo "[info] extracting..."
    tar xf "$TARBALL"
fi

cd "dinit-${VERSION}"

# build
JOBS=$(nproc)
echo "[info] compiling with ${JOBS} jobs..."
make -j"$JOBS" DINIT_CROSS_COMPILE=

# install
echo "[info] installing..."
make install PREFIX=/usr DESTDIR=/

# install service directories
echo "[info] installing service directories..."
mkdir -p /etc/dinit.d/boot.d
mkdir -p /etc/dinit.d/service.d
mkdir -p /etc/dinit.d/user.d

# copy default services if present
if [ -d "dinit.d" ]; then
    cp -r dinit.d/* /etc/dinit.d/ 2>/dev/null || true
fi

# cleanup
cd /
rm -rf "$BUILD_DIR"

echo "[info] dinit ${VERSION} installed"
echo "[info] binary: /usr/sbin/dinit"
echo "[info] services: /etc/dinit.d/"
