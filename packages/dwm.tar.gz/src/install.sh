#!/bin/bash
set -e
[ "$(id -u)" -ne 0 ] && { echo "[error] must be root" >&2; exit 1; }

BUILD="/tmp/sdpm-dwm-build"

echo "[info] building dwm..."
mkdir -p "$BUILD" && cd "$BUILD"

[ ! -f "dwm-6.5.tar.gz" ] && \
    curl -fSL "https://dl.suckless.org/dwm/dwm-6.5.tar.gz" -o dwm-6.5.tar.gz
[ ! -d "dwm-6.5" ] && tar xf dwm-6.5.tar.gz
cd dwm-5

make -j"$(nproc)"
make install PREFIX=/usr/local

cd / && rm -rf "$BUILD"
echo "[info] dwm installed to /usr/local/bin/dwm"
