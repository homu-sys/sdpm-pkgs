#!/bin/bash
set -e
[ "$(id -u)" -ne 0 ] && { echo "[error] must be root" >&2; exit 1; }

echo "[info] installing dependencies..."
pacman -S --needed --noconfirm \
    gcc make pkg-config \
    libx11 imlib2 libjpeg-turbo libpng \
    curl wget \
    > /dev/null 2>&1 || true

BUILD="/tmp/sdpm-feh-build"
mkdir -p "$BUILD" && cd "$BUILD"

if [ ! -d "feh" ]; then
    git clone --depth 1 https://github.com/derf/feh.git
fi

cd feh
make PREFIX=/usr/local
make PREFIX=/usr/local install

cd / && rm -rf "$BUILD"
echo "[info] feh installed"
