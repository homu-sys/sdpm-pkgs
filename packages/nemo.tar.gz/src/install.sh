#!/bin/bash
set -e
[ "$(id -u)" -ne 0 ] && { echo "[error] must be root" >&2; exit 1; }

echo "[info] installing dependencies..."
pacman -S --needed --noconfirm \
    meson ninja gcc pkg-config \
    gtk3 glib2 libxml2 libnotify \
    cinnamon-desktop libmediaplayerid \
    desktop-file-utils dconf cjs \
    > /dev/null 2>&1 || true

BUILD="/tmp/sdpm-nemo-build"
mkdir -p "$BUILD" && cd "$BUILD"

if [ ! -d "nemo" ]; then
    git clone --depth 1 https://github.com/linuxmint/nemo.git
fi

cd nemo
meson setup build --prefix=/usr/local
ninja -C build
ninja -C build install

cd / && rm -rf "$BUILD"
echo "[info] nemo installed"
