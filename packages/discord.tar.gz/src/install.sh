#!/bin/bash
set -e
[ "$(id -u)" -ne 0 ] && { echo "[error] must be root" >&2; exit 1; }

echo "[info] installing dependencies..."
pacman -S --needed --noconfirm \
    alsa-lib atk at-spi2-atk cups \
    libdrm libgbm libxcomposite libxdamage \
    libxrandr mesa nss pango gtk3 \
    > /dev/null 2>&1 || true

BUILD="/tmp/sdpm-discord-build"
mkdir -p "$BUILD" && cd "$BUILD"

if [ ! -d "discord" ]; then
    curl -L -o discord.tar.gz "https://discord.com/api/download?platform=linux&format=tar.gz"
    tar xzf discord.tar.gz
    mv Discord /opt/discord
fi

ln -sf /opt/discord/Discord /usr/local/bin/discord

cd / && rm -rf "$BUILD"
echo "[info] discord installed"
