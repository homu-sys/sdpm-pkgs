#!/bin/bash
set -e
[ "$(id -u)" -ne 0 ] && { echo "[error] must be root" >&2; exit 1; }

echo "[info] installing dependencies..."
pacman -S --needed --noconfirm \
    autoconf2.13 cargo clang dbus-glib gconf \
    gtk3 libasound.so libpulse python-bindgen \
    unzip wget zip nasm \
    > /dev/null 2>&1 || true

BUILD="/tmp/sdpm-firefox-build"
mkdir -p "$BUILD" && cd "$BUILD"

if [ ! -d "firefox" ]; then
    curl -L -o firefox.tar.bz2 "https://download.mozilla.org/?product=firefox-latest&os=linux64&lang=en-US"
    tar xjf firefox.tar.bz2
    mv firefox /opt/firefox
fi

ln -sf /opt/firefox/firefox /usr/local/bin/firefox

cd / && rm -rf "$BUILD"
echo "[info] firefox installed"
