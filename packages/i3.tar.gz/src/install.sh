#!/bin/bash
set -e
[ "$(id -u)" -ne 0 ] && { echo "[error] must be root" >&2; exit 1; }

echo "[info] installing dependencies..."
pacman -S --needed --noconfirm \
    gcc make autoconf automake libtool \
    libxcb xcb-util xcb-util-keysyms xcb-util-wm \
    xcb-util-xrm libev yajl pango startup-notification \
    xorg-xprop xorg-xev \
    > /dev/null 2>&1 || true

BUILD="/tmp/sdpm-i3-build"
mkdir -p "$BUILD" && cd "$BUILD"

if [ ! -d "i3" ]; then
    git clone --depth 1 https://github.com/i3/i3.git
fi

cd i3
meson setup build --prefix=/usr/local
ninja -C build
ninja -C build install

cd / && rm -rf "$BUILD"
echo "[info] i3 installed"
