#!/bin/bash
set -e
[ "$(id -u)" -ne 0 ] && { echo "[error] must be root" >&2; exit 1; }

echo "[info] installing dependencies..."
pacman -S --needed --noconfirm \
    meson ninja gcc pkg-config \
    ffmpeg libplacebo vulkan-icd-loader \
    libxkbcommon wayland-protocols \
    libdrm pulseaudio alsa-lib \
    > /dev/null 2>&1 || true

BUILD="/tmp/sdpm-mpv-build"
mkdir -p "$BUILD" && cd "$BUILD"

if [ ! -d "mpv" ]; then
    git clone --depth 1 https://github.com/mpv-player/mpv.git
fi

cd mpv
meson setup build --prefix=/usr/local \
    -Dcdda=disabled \
    -Ddvbin=disabled \
    -Ddvdnav=disabled
ninja -C build
ninja -C build install

cd / && rm -rf "$BUILD"
echo "[info] mpv installed"
