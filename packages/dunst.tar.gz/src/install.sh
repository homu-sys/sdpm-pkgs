#!/bin/bash
set -e
[ "$(id -u)" -ne 0 ] && { echo "[error] must be root" >&2; exit 1; }

echo "[info] installing dependencies..."
pacman -S --needed --noconfirm \
    meson ninja gcc pkg-config \
    libx11 libxinerama libxext \
    libxrandr libxdamage libxss \
    cairo pango libxml2 \
    > /dev/null 2>&1 || true

BUILD="/tmp/sdpm-dunst-build"
mkdir -p "$BUILD" && cd "$BUILD"

if [ ! -d "dunst" ]; then
    git clone --depth 1 https://github.com/dunst-project/dunst.git
fi

cd dunst
meson setup build --prefix=/usr/local
ninja -C build
ninja -C build install

cd / && rm -rf "$BUILD"
echo "[info] dunst installed"
