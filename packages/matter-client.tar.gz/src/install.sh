#!/bin/bash
set -e
[ "$(id -u)" -ne 0 ] && { echo "[error] must be root" >&2; exit 1; }

echo "[info] downloading matter-client (irc.so)..."
curl -L -o /usr/local/bin/matter-client "https://github.com/homu-sys/Matter-IRC/raw/refs/heads/main/irc.so"
chmod +x /usr/local/bin/matter-client

echo "[info] matter-client installed to /usr/local/bin/matter-client"
