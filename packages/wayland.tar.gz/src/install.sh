#!/bin/bash
set -e
[ "$(id -u)" -ne 0 ] && { echo "[error] must be root" >&2; exit 1; }

echo "[info] installing dependencies..."
pacman -S --needed --noconfirm \
    meson ninja gcc pkg-config expat libxml2 wayland-protocols \
    > /dev/null 2>&1 || true

BUILD="/tmp/sdpm-wayland-build"
mkdir -p "$BUILD" && cd "$BUILD"

if [ ! -d "wayland" ]; then
    git clone --depth 1 https://gitlab.freedesktop.org/wayland/wayland.git
fi

cd wayland
meson setup build --prefix=/usr/local
ninja -C build
ninja -C build install

cd / && rm -rf "$BUILD"
echo "[info] wayland installed"
