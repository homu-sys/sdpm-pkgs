#!/bin/bash
set -e
[ "$(id -u)" -ne 0 ] && { echo "[error] must be root" >&2; exit 1; }

VERSION="${1:-257}"
BUILD="/tmp/sdpm-systemd-build"

echo "[info] building systemd v${VERSION}..."
mkdir -p "$BUILD" && cd "$BUILD"

TARBALL="systemd-${VERSION}.tar.gz"
[ ! -f "$TARBALL" ] && \
    curl -fSL "https://github.com/systemd/systemd/archive/refs/tags/v${VERSION}.tar.gz" -o "$TARBALL"
[ ! -d "systemd-${VERSION}" ] && tar xf "$TARBALL"
cd "systemd-${VERSION}"

meson setup build -Dmode=release -Dtests=false -Dpam=false -Dselinux=false -Dseccomp=false
ninja -C build
ninja -C build install

cd / && rm -rf "$BUILD"
echo "[info] systemd v${VERSION} installed"
