#!/bin/bash
set -e
[ "$(id -u)" -ne 0 ] && { echo "[error] must be root" >&2; exit 1; }

echo "[info] installing dependencies..."
pacman -S --needed --noconfirm \
    meson ninja gcc pkg-config xorgproto libXrandr \
    > /dev/null 2>&1 || true

BUILD="/tmp/sdpm-xrandr-build"
mkdir -p "$BUILD" && cd "$BUILD"

if [ ! -d "xrandr" ]; then
    git clone --depth 1 https://gitlab.freedesktop.org/xorg/app/xrandr.git
fi

cd xrandr
meson setup build --prefix=/usr/local
ninja -C build
ninja -C build install

cd / && rm -rf "$BUILD"
echo "[info] xorg-xrandr installed"
