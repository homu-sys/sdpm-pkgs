#!/bin/bash
set -e
[ "$(id -u)" -ne 0 ] && { echo "[error] must be root" >&2; exit 1; }

echo "[info] installing dependencies..."
pacman -S --needed --noconfirm \
    meson ninja gcc pkg-config xorgproto libpciaccess \
    libxfont libxfont2 pixman libxkbfile libXfont2 \
    xorg-server-devel libgl libepoxy \
    > /dev/null 2>&1 || true

BUILD="/tmp/sdpm-xorg-server-build"
mkdir -p "$BUILD" && cd "$BUILD"

if [ ! -d "xorg-server" ]; then
    git clone --depth 1 https://gitlab.freedesktop.org/xorg/server/xorg-server.git
fi

cd xorg-server
meson setup build --prefix=/usr/local
ninja -C build
ninja -C build install

cd / && rm -rf "$BUILD"
echo "[info] xorg-server installed"
