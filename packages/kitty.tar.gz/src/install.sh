#!/bin/bash
set -e
[ "$(id -u)" -ne 0 ] && { echo "[error] must be root" >&2; exit 1; }

echo "[info] installing dependencies..."
pacman -S --needed --noconfirm \
    librsync openssl libpng freetype harfbuzz fontconfig \
    wayland-protocols wayland libxkbcommon libgl egl \
    > /dev/null 2>&1 || true

BUILD="/tmp/sdpm-kitty-build"
mkdir -p "$BUILD" && cd "$BUILD"

if [ ! -d "kitty" ]; then
    git clone --depth 1 https://github.com/kovidgoyal/kitty.git
fi

cd kitty
cmake -B build -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX=/usr/local
cmake --build build -j"$(nproc)"
cmake --install build

cd / && rm -rf "$BUILD"
echo "[info] kitty installed"
