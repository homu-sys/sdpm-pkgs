#!/bin/bash
set -e
[ "$(id -u)" -ne 0 ] && { echo "[error] must be root" >&2; exit 1; }

echo "[info] installing base build tools..."
pacman -S --needed --noconfirm \
    base-devel gcc make cmake meson ninja \
    git pkg-config autoconf automake libtool \
    unzip curl wget \
    > /dev/null 2>&1

echo "[info] installing flatpak dependencies..."
pacman -S --needed --noconfirm \
    libsoup json-glib libseccomp polkit \
    fuse3 libarchive libsodium bubblewrap \
    > /dev/null 2>&1

BUILD="/tmp/sdpm-flatpak-build"
mkdir -p "$BUILD" && cd "$BUILD"

if [ ! -d "flatpak" ]; then
    git clone --depth 1 https://github.com/flatpak/flatpak.git
fi

cd flatpak
meson setup build --prefix=/usr/local \
    -Dsystemd=disabled \
    -Ddocbook=disabled \
    -Dtests=disabled
ninja -C build
ninja -C build install

cd / && rm -rf "$BUILD"

echo "[info] adding flathub remote..."
flatpak remote-add --if-not-exists flathub https://flathub.org/repo/flathub.flatpakrepo 2>/dev/null || true

echo "[info] flatpak-bootstrap complete"
