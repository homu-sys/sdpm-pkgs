#!/bin/bash
set -e
[ "$(id -u)" -ne 0 ] && { echo "[error] must be root" >&2; exit 1; }

VERSION="${1:-0.6.3}"
BUILD="/tmp/sdpm-supertux-build"

echo "[info] installing dependencies..."
pacman -S --needed --noconfirm \
    boost sdl2 sdl2_image sdl2_mixer sdl2_ttf \
    libogg libvorbis libpng libwebp \
    curl zlibphysfs glew > /dev/null 2>&1 || true

echo "[info] downloading supertux ${VERSION}..."
mkdir -p "$BUILD" && cd "$BUILD"

if [ ! -d "supertux" ]; then
    git clone --depth 1 --branch "v${VERSION}" \
        https://github.com/SuperTux/supertux.git supertux
fi

cd supertux

sed -i 's/cmake_minimum_required(VERSION.*/cmake_minimum_required(VERSION 3.5...4.0)/' CMakeLists.txt

echo "[info] building supertux ${VERSION}..."
cmake -B build -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_INSTALL_PREFIX=/usr/local \
    -DENABLE_OPENGLES2=OFF
cmake --build build -j"$(nproc)"
cmake --install build

cd / && rm -rf "$BUILD"
echo "[info] supertux ${VERSION} installed"
