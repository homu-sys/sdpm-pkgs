#!/bin/bash
set -e
[ "$(id -u)" -ne 0 ] && { echo "[error] must be root" >&2; exit 1; }

VERSION="${1:-0.6.3}"
BUILD="/tmp/sdpm-supertux-build"

echo "[info] downloading supertux ${VERSION}..."
mkdir -p "$BUILD" && cd "$BUILD"

if [ ! -d "supertux" ]; then
    git clone --depth 1 --branch "v${VERSION}" \
        https://github.com/SuperTux/supertux.git supertux
fi

cd supertux

echo "[info] building supertux ${VERSION}..."
cmake -B build -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_INSTALL_PREFIX=/usr/local \
    -DCMAKE_POLICY_VERSION_MINIMUM=3.5 \
    -DENABLE_OPENGLES2=OFF
cmake --build build -j"$(nproc)"
cmake --install build

cd / && rm -rf "$BUILD"
echo "[info] supertux ${VERSION} installed"
